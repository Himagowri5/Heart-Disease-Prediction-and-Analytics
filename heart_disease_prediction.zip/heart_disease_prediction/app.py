# app.py
import streamlit as st
import pandas as pd
import pickle
import seaborn as sns
import matplotlib.pyplot as plt

# Load model
with open("model.pkl", "rb") as f:
    model = pickle.load(f)

# Load dataset
df = pd.read_csv("data/framingham.csv")
if "education" in df.columns:
    df = df.drop(columns=["education"])
df = df.dropna()

# Map binary columns to Yes/No for display
df['male'] = df['male'].map({1: "Male", 0: "Female"})
df['currentSmoker'] = df['currentSmoker'].map({1: "Yes", 0: "No"})
df['BPMeds'] = df['BPMeds'].map({1: "Yes", 0: "No"})
df['prevalentStroke'] = df['prevalentStroke'].map({1: "Yes", 0: "No"})
df['prevalentHyp'] = df['prevalentHyp'].map({1: "Yes", 0: "No"})
df['diabetes'] = df['diabetes'].map({1: "Yes", 0: "No"})
df['TenYearCHD'] = df['TenYearCHD'].map({1: "Yes", 0: "No"})

# App Layout
st.set_page_config(page_title="Heart Disease Predictor", layout="wide")
st.title("💓 Heart Disease Prediction & Analytics")

# Sidebar menu
menu = st.sidebar.radio("Navigation", ["Prediction", "Analytics Dashboard"])

# ---------------- Prediction Page ----------------
if menu == "Prediction":
    st.header("🔮 Predict 10-Year Heart Disease Risk")

    # Input form
    col1, col2 = st.columns(2)

    with col1:
        gender = st.selectbox("Gender", ["Male", "Female"])
        age = st.number_input("Age", 20, 100, 40)
        smoker = st.selectbox("Current Smoker", ["Yes", "No"])
        cigsPerDay = st.number_input("Cigarettes per Day", 0, 60, 0)
        bpmeds = st.selectbox("On BP Medication?", ["Yes", "No"])

    with col2:
        prev_stroke = st.selectbox("Previous Stroke", ["Yes", "No"])
        prev_hyp = st.selectbox("Hypertension", ["Yes", "No"])
        diabetes = st.selectbox("Diabetes", ["Yes", "No"])
        totChol = st.number_input("Total Cholesterol", 100, 600, 200)
        sysBP = st.number_input("Systolic BP", 80, 250, 120)
        diaBP = st.number_input("Diastolic BP", 50, 150, 80)
        bmi = st.number_input("BMI", 10.0, 50.0, 25.0)
        heartRate = st.number_input("Heart Rate", 40, 200, 70)
        glucose = st.number_input("Glucose", 40, 400, 80)

    if st.button("Predict Risk"):
        # Convert categorical to numbers (backend only)
        input_data = [[
            1 if gender == "Male" else 0,
            age,
            1 if smoker == "Yes" else 0,
            cigsPerDay,
            1 if bpmeds == "Yes" else 0,
            1 if prev_stroke == "Yes" else 0,
            1 if prev_hyp == "Yes" else 0,
            1 if diabetes == "Yes" else 0,
            totChol,
            sysBP,
            diaBP,
            bmi,
            heartRate,
            glucose
        ]]

        prediction = model.predict(input_data)[0]

        if prediction == 1:
            st.error("⚠️ High Risk of Heart Disease within 10 years!")
        else:
            st.success("✅ Low Risk of Heart Disease within 10 years.")

# ---------------- Analytics Dashboard ----------------
elif menu == "Analytics Dashboard":
    st.header("📊 Explore Heart Disease Data")

    question = st.selectbox(
        "Choose Analysis",
        ["CHD by Gender", "CHD by Age Groups", "CHD by Smoking", "CHD by Diabetes", "Cholesterol vs CHD"]
    )

    if question == "CHD by Gender":
        fig, ax = plt.subplots()
        sns.countplot(data=df, x="male", hue="TenYearCHD", palette="Set2", ax=ax)
        ax.set_title("CHD Distribution by Gender")
        st.pyplot(fig)

    elif question == "CHD by Age Groups":
        df['age_group'] = pd.cut(df['age'], bins=[20,30,40,50,60,70,80], labels=["20-30","30-40","40-50","50-60","60-70","70-80"])
        fig, ax = plt.subplots()
        sns.barplot(data=df, x="age_group", y=df['TenYearCHD'].map({"No":0, "Yes":1}), ci=None, ax=ax)
        ax.set_title("CHD Rate by Age Group")
        ax.set_ylabel("CHD Rate")
        st.pyplot(fig)

    elif question == "CHD by Smoking":
        fig, ax = plt.subplots()
        sns.countplot(data=df, x="currentSmoker", hue="TenYearCHD", palette="Set2", ax=ax)
        ax.set_title("CHD by Smoking Status")
        st.pyplot(fig)

    elif question == "CHD by Diabetes":
        fig, ax = plt.subplots()
        sns.countplot(data=df, x="diabetes", hue="TenYearCHD", palette="Set2", ax=ax)
        ax.set_title("CHD by Diabetes")
        st.pyplot(fig)

    elif question == "Cholesterol vs CHD":
        fig, ax = plt.subplots()
        sns.histplot(data=df, x="totChol", hue="TenYearCHD", kde=True, element="step", ax=ax)
        ax.set_title("Cholesterol Levels vs CHD")
        st.pyplot(fig)
